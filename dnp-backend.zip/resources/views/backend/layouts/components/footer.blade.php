<footer class="footer undefined undefined">
    <p class="clearfix text-muted m-0"><span>{{ translate('Copyright') }} &copy; {{ date('Y') }} &nbsp;</span>
        <a href="#" target="_blank">{{ get_setting('site_name') }}</a>
        <span class="d-none d-sm-inline-block">
            {{ translate('All rights reserved') }}.</span>
    </p>
</footer>
<!-- End : Footer-->
<!-- Scroll to top button -->
<button class="btn btn-primary scroll-top" type="button"><i class="ft-arrow-up"></i></button>
