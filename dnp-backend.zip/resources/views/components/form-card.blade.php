<div class="card statistcs_card admin_statistcs m-0 mb-3">
    <div class="card-header">
        <span>{{ $title }}</span>
    </div>
    <div class="card-body d-block">
        {{ $slot }}
    </div>
</div>
