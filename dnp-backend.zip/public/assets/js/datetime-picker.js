(function (window, document, $) {
  // Basic date
  if ($('.pickadate').length > 0) {
    $('.pickadate').pickadate();
  }

  // Basic time
  if ($('.pickatime').length > 0) {
    $('.pickatime').pickatime();
  }
})(window, document, jQuery);
