$(document).ready(function(){
    $('.app-sidebar').on('mouseenter', function () {
        $(this).removeClass('expanded');
    });
})